package org.example;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

public class MongoDBConnection {
    public static void main(String[] args) {
        // Creează conexiunea utilizând MongoClients.create()
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");

        // Cod suplimentar pentru accesarea bazei de date
        var database = mongoClient.getDatabase("proiect_russian_rulet");
        var collection = database.getCollection("jocuri");

        // Adăugarea unui document în colecție
        var document = new org.bson.Document("nume", "Russian Roulette")
                .append("jucatori", 2)
                .append("status", "activ");
        collection.insertOne(document);

        System.out.println("Document adăugat cu succes!");

        // Închiderea conexiunii
        mongoClient.close();
    }
}

