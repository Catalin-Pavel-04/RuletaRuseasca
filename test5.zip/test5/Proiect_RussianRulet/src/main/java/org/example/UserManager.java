package org.example;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserManager {
    private final MongoCollection<Document> userCollection;

    public UserManager(MongoCollection<Document> userCollection) {
        this.userCollection = userCollection;
    }

    public void inregistrareUtilizator(String username, String password) {
        // Verificăm dacă utilizatorul deja există
        Document utilizator = userCollection.find(new Document("username", username)).first();

        if (utilizator != null) {
            System.out.println("❌ Utilizatorul \"" + username + "\" există deja.");
        } else {
            // Creăm un document nou pentru utilizator
            Document nouUtilizator = new Document("username", username)
                    .append("password", password) // Adăugăm parola
                    .append("scor", 0); // Inițializăm scorul la 0
            userCollection.insertOne(nouUtilizator);
            System.out.println("✅ Utilizatorul \"" + username + "\" a fost înregistrat cu succes.");
        }
    }



    public boolean autentificareUtilizator(String username, String password) {
        // Căutăm utilizatorul în baza de date
        Document utilizator = userCollection.find(new Document("username", username)).first();

        if (utilizator != null) {
            // Verificăm dacă parola este corectă
            if (utilizator.getString("password").equals(password)) {
                System.out.println("✅ Autentificare reușită pentru utilizatorul \"" + username + "\".");
                return true;
            } else {
                System.out.println("❌ Parola este incorectă.");
                return false;
            }
        } else {
            System.out.println("❌ Utilizatorul \"" + username + "\" nu există.");
            return false;
        }
    }



    public void actualizareScor(String username, int scor) {
        Document query = new Document("username", username);
        Document update = new Document("$set", new Document("scor", scor));
        userCollection.updateOne(query, update);
        System.out.println("Scor actualizat cu succes!");
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Eroare la hash-ul parolei.", e);
        }
    }

    public void afisareScoreboard() {
        System.out.println("\n🏆 Scoreboard:");

        // Obține toți utilizatorii din colecția utilizatori, excluzând pe "admin"
        List<Document> utilizatori = userCollection.find(new Document("username", new Document("$ne", "admin")))
                .into(new ArrayList<>());

        // Sortează utilizatorii după scor descrescător
        utilizatori.sort((u1, u2) -> Integer.compare(
                u2.getInteger("scor", 0), // Scorul utilizatorului 2
                u1.getInteger("scor", 0)  // Scorul utilizatorului 1
        ));

        // Afișează utilizatorii și scorurile lor
        if (utilizatori.isEmpty()) {
            System.out.println("⚠️ Nu există utilizatori înregistrati în afară de admin.");
        } else {
            for (int i = 0; i < utilizatori.size(); i++) {
                Document user = utilizatori.get(i);
                System.out.printf("%d. %s - %d puncte\n",
                        i + 1,
                        user.getString("username"),
                        user.getInteger("scor", 0)
                );
            }
        }

        System.out.println(); // Linie goală pentru separare
    }


}
